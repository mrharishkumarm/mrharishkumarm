package com.example.sosalertv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ScheduledExecutorService;

public class MainActivity extends AppCompatActivity {
    int i = 0;
    String hostName = "http://172.20.10.7/";
    boolean canSend = false;
    private Handler mHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button sosButton = findViewById(R.id.sos_button);
        sosButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button bsos = (Button) v;
                i++;
                if(bsos.getText().toString().toLowerCase().contains("on")){
                    System.out.println(bsos.getText().toString()+" AAAAAAAAAAAAAAAA "+i+" "+bsos.getText().toString().toLowerCase().contains("on"));
                    bsos.setText("SOS OFF");
                    canSend = true;

                }else{
                    System.out.println(bsos.getText().toString()+" VVVVVVVVVVVVVVVVVV "+i+" "+bsos.getText().toString().toLowerCase().contains("on"));
                    bsos.setText("SOS ON");
                    canSend = false;
                    return;
                }
            }
        });


        mHandler = new Handler(Looper.getMainLooper());
        Runnable myTask = new Runnable() {
            @Override
            public void run() {
                System.out.println("Called ......");
                sendGeoData();
                mHandler.postDelayed(this, 1000);
            }
        };
        mHandler.postDelayed(myTask, 1000);

        //volleySimple();
    }

    private void volleySimple(){
        Log.d("WISEN>>>","Volley Simple Called");
        String url = hostName+"processRegister";

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("WISEN>>>", "Response is: "+ response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Log.d("WISEN>>>","That didn't work!"+error);
            }
        });
        Log.d("WISEN>>>","Volley Simple Called");
        requestQueue.add(stringRequest);


    }
    LocationTrack locationTrack;
    double longitude = 0;
    double latitude = 0;
    private void getLocation(){
        locationTrack = new LocationTrack(MainActivity.this);


        if (locationTrack.canGetLocation()) {


            longitude = locationTrack.getLongitude();
            latitude = locationTrack.getLatitude();

            Toast.makeText(getApplicationContext(), "Longitude:" + Double.toString(longitude) + "\nLatitude:" + Double.toString(latitude), Toast.LENGTH_SHORT).show();
        } else {

            locationTrack.showSettingsAlert();
        }
    }

    private void sendGeoData() {
        System.out.println("sendGeoData Called");
        if (canSend == false)
            return;
        this.getLocation();
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest sr = new StringRequest(Request.Method.POST, hostName+"processGeo",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                })
        {
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String, String>();
                params.put("latitude",latitude+"");
                params.put("longitude",longitude+"");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("Content-Type","application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(sr);
    }

}