class RemoteDataModel:
    # instance attribute
    def __init__(self, uniqueID, fullName="", phoneNbr="", longtitude=0,latitude=0, imageFileName="", isBlockChainGenerated=0, hash="", prevHash=""):
        self.uniqueID=uniqueID
        self.fullName=fullName
        self.phoneNbr = phoneNbr
        self.longtitude = longtitude
        self.latitude = latitude
        self.imageFileName=imageFileName
        self.isBlockChainGenerated = isBlockChainGenerated
        self.hash = hash
        self.prevHash = prevHash

