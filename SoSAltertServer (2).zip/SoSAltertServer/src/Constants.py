serverName = "WISEN\SQLEXPRESS"
databaseName = "RemoteDataV1"
connString = 'Driver={SQL Server};Server='+serverName+';Integrated_Security=true;Database='+databaseName